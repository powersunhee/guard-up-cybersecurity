# TypeScript Application

A modern TypeScript application with a complete development setup.

## Features

- TypeScript 5.3
- Jest for testing
- Hot reloading during development
- Source maps support
- Modern ES2020 features

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

4. Run tests:
   ```bash
   npm test
   ```

## Scripts

- `npm start` - Run the application
- `npm run dev` - Start development server with hot reloading
- `npm run build` - Build for production
- `npm test` - Run tests

## Project Structure

- `src/` - Source files
- `dist/` - Compiled output
- `__tests__/` - Test files 