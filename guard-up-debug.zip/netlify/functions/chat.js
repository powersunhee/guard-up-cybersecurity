const OpenAI = require('openai');

exports.handler = async (event, context) => {
  // Handle CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' }),
    };
  }

  try {
    // Parse the request body
    const { message, conversation = [] } = JSON.parse(event.body);

    if (!message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Message is required' }),
      };
    }

    // Initialize OpenAI with v4 API
    const openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    // Create the system prompt for cybersecurity context
    const systemPrompt = `You are a cybersecurity expert assistant for "Guard Up", a cybersecurity awareness training app. Your role is to:

1. Help users identify potential scams, phishing attempts, and security threats
2. Analyze suspicious messages, emails, phone numbers, and links
3. Provide clear, actionable cybersecurity advice
4. Explain security concepts in simple terms
5. Be encouraging and supportive while maintaining security focus

Guidelines:
- Always prioritize user safety
- Provide specific, actionable advice
- Use clear, non-technical language when possible
- If analyzing content, point out specific red flags
- Encourage verification through official channels
- Be concise but thorough

Current conversation context: This is a cybersecurity training app where users learn about threats and can ask for help analyzing suspicious content.`;

    // Prepare messages for OpenAI
    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversation.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'assistant',
        content: msg.message
      })),
      { role: 'user', content: message }
    ];

    // Call OpenAI API with v4 format
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: messages,
      max_tokens: 500,
      temperature: 0.7,
      presence_penalty: 0.1,
      frequency_penalty: 0.1,
    });

    const response = completion.choices[0].message.content;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        response: response,
        success: true
      }),
    };

  } catch (error) {
    console.error('Error:', error);
    
    // Handle specific OpenAI errors
    if (error.status === 401) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid OpenAI API key',
          fallback: "I'm having trouble connecting to my AI services right now. For immediate help, please verify suspicious messages through official channels and avoid clicking any links or providing personal information."
        }),
      };
    }

    if (error.status === 429) {
      return {
        statusCode: 429,
        headers,
        body: JSON.stringify({ 
          error: 'Rate limit exceeded',
          fallback: "I'm experiencing high demand right now. Please try again in a moment. In the meantime, remember: when in doubt about a message's authenticity, verify through official channels."
        }),
      };
    }

    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        fallback: "I'm having technical difficulties. For cybersecurity help, remember these key principles: verify sender identity, don't click suspicious links, and trust your instincts if something feels wrong."
      }),
    };
  }
}; 